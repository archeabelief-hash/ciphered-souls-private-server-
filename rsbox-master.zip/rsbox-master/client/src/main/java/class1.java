public interface class1 {
}
