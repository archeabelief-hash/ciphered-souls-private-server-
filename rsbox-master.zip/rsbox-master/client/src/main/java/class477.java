public interface class477 {
}
