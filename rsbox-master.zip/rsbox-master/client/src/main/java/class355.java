public interface class355 {
}
